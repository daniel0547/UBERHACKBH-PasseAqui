from flask import render_template, request, redirect, url_for, send_from_directory
from app import app
from app.utils import *

@app.route('/')
@app.route('/index')
def index():
	return render_template('index.html', latitude="-19.9194331", longitude="-44.0176182")


@app.route('/build', methods=['GET', 'POST'])
def build():
	if(request.form['origem_lat'] and request.form['origem_lng'] and request.form['destino_lat'] and request.form['destino_lng']):
		olat=request.form['origem_lat'];
		olng=request.form['origem_lng'];
		dlat=request.form['destino_lat'];
		dlng=request.form['destino_lng'];
		route=calcroute(olng,olat,dlng,dlat)
		points=[]
		for p in route['coordinates']:
			points.append([p[0],p[1],p[2]])
		print('---------------------------')
		print(points)
		print('---------------------------')
		return render_template('result.html', latitude="-19.9194331", longitude="-44.0176182", points=points);

@app.route('/serviceworker.js')
def static_from_root():
    return send_from_directory(app.static_folder, 'sw.js')
