let baseLayer = L.tileLayer(
  'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
    maxZoom: 18
  }
);

let origem=null;
let destino=null;

let map = new L.Map('map', {
  center: new L.LatLng(latitude, longitude),
  zoom: 10,
  layers: [baseLayer]
});

nodeObj ={
  lat:latitude,
  lng:longitude,
  marker: L.marker([latitude,longitude])
}

map.on('click', function(e){
	let lat = e.latlng.lat;
	let lng = e.latlng.lng;
	let node = {
		lat:lat,
		lng:lng
	}
	add(node)
	console.log("Clicked " + lat + "," + lng);
});


function searchandgo(){
	let query = $('#searchPlace').val();
	let url="https://nominatim.openstreetmap.org/search/"
	let frmt="?format=json";
	theUrl=url+query+frmt;
	$.getJSON(theUrl, function(data) {
	    console.log(data)
			map.setView([data[0].lat, data[0].lon],18);
	});
}



function add(node){
	nodeObj ={
		lat:node.lat,
		lng:node.lng,
		marker: L.marker([node.lat,node.lng])
	}
	if(origem){
		if(destino){
			destino.marker.removeFrom(map);
		}
		destino=nodeObj;
	}
	else{
		origem=nodeObj;
	}
	nodeObj.marker.addTo(map);
}

function submitpoint(){
  let form = $('#input_form');
	$('#origem_lat').val(origem.lat);
	$('#origem_lng').val(origem.lng);
	$('#destino_lat').val(destino.lat);
	$('#destino_lng').val(destino.lng);
  form.submit()
}
