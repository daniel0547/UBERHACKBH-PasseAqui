let baseLayer = L.tileLayer(
  'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
    maxZoom: 18
  }
);

let origem=null;
let destino=null;

let map = new L.Map('map', {
  center: new L.LatLng(latitude, longitude),
  zoom: 10,
  layers: [baseLayer]
});

nodeObj ={
  lat:latitude,
  lng:longitude,
  marker: L.marker([latitude,longitude])
}

map.on('click', function(e){
	let lat = e.latlng.lat;
	let lng = e.latlng.lng;
	let node = {
		lat:lat,
		lng:lng
	}
	add(node)
	console.log("Clicked " + lat + "," + lng);
});

//var polyline = L.polyline(points, {color: 'red'}).addTo(map);
let geojson = [{
"type": "FeatureCollection",
"features": [{
    "type": "Feature",
    "geometry": {
        "type": "LineString",
        "coordinates": points
    },
		"properties": {
				"attributeType": 1
		}
}],
"properties": {
        "Creator": "OpenRouteService.org",
        "records": 1,
        "summary": "steepness"
}}]
L.geoJson(geojson).addTo(map);
var hg = L.control.heightgraph({
    width: 800,
    height: 280,
    margins: {
        top: 10,
        right: 30,
        bottom: 55,
        left: 50
    },
    position: "bottomright",
    mappings: undefined || colorMappings
});
hg.addTo(map);
hg.addData(geojson);
window.onload = function() {
	$('.heightgraph-close-icon')[0].click()
}
function add(node){
	nodeObj ={
		lat:node.lat,
		lng:node.lng,
		marker: L.marker([node.lat,node.lng])
	}
	if(origem){
		if(destino){
			destino.marker.removeFrom(map);
		}
		destino=nodeObj;
	}
	else{
		origem=nodeObj;
	}
	nodeObj.marker.addTo(map);
}

function submitpoint(){
  let form = $('#input_form');
	$('#origem_lat').val(origem.lat);
	$('#origem_lng').val(origem.lng);
	$('#destino_lat').val(destino.lat);
	$('#destino_lng').val(destino.lng);
  form.submit()
}
